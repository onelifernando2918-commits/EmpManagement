import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EmployeeManagementDB extends JFrame {

    Connection conn;
    PreparedStatement pstmt;
    Statement stmt;
    ResultSet rs;

    JTable table;
    DefaultTableModel model;
    JTextField txtName, txtAge, txtSalary, txtDesignation, txtOvertime, txtBonus;
    JButton btnAdd, btnUpdate, btnDelete, btnRefresh;

    public EmployeeManagementDB() {
        setTitle("Employee Management System - Task 3");
        setSize(900, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "Name", "Age", "Salary", "Designation", "Overtime Rate", "Bonus", "Tax", "Net Salary"
        }, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // --- Edited layout part ---
        JPanel inputPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtName = new JTextField();
        txtAge = new JTextField();
        txtSalary = new JTextField();
        txtDesignation = new JTextField();
        txtOvertime = new JTextField();
        txtBonus = new JTextField();

        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Name"), gbc);

        gbc.gridx = 1;
        inputPanel.add(new JLabel("Age"), gbc);

        gbc.gridx = 2;
        inputPanel.add(new JLabel("Salary"), gbc);

        gbc.gridx = 3;
        inputPanel.add(new JLabel("Designation"), gbc);

        gbc.gridx = 4;
        inputPanel.add(new JLabel("Overtime Rate"), gbc);

        gbc.gridx = 5;
        inputPanel.add(new JLabel("Bonus"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(txtName, gbc);

        gbc.gridx = 1;
        inputPanel.add(txtAge, gbc);

        gbc.gridx = 2;
        inputPanel.add(txtSalary, gbc);

        gbc.gridx = 3;
        inputPanel.add(txtDesignation, gbc);

        gbc.gridx = 4;
        inputPanel.add(txtOvertime, gbc);

        gbc.gridx = 5;
        inputPanel.add(txtBonus, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        inputPanel.add(btnAdd = new JButton("Add"), gbc);

        gbc.gridx = 1;
        inputPanel.add(btnUpdate = new JButton("Update"), gbc);

        gbc.gridx = 2;
        inputPanel.add(btnDelete = new JButton("Delete"), gbc);

        gbc.gridx = 3;
        inputPanel.add(btnRefresh = new JButton("Refresh"), gbc);

        add(inputPanel, BorderLayout.SOUTH);
        // --- End edited layout part ---

        // Database Connection
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/employee_db", "root", ""
            );
            stmt = conn.createStatement();
            System.out.println(" Connected to Database");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "DB Connection Error: " + e.getMessage());
        }

        // Button Actions
        btnAdd.addActionListener(e -> addEmployee());
        btnUpdate.addActionListener(e -> updateEmployee());
        btnDelete.addActionListener(e -> deleteEmployee());
        btnRefresh.addActionListener(e -> loadEmployees());
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    txtName.setText(model.getValueAt(selectedRow, 1).toString());
                    txtAge.setText(model.getValueAt(selectedRow, 2).toString());
                    txtSalary.setText(model.getValueAt(selectedRow, 3).toString());
                    txtDesignation.setText(model.getValueAt(selectedRow, 4).toString());
                    txtOvertime.setText(model.getValueAt(selectedRow, 5) == null ? "" : model.getValueAt(selectedRow, 5).toString());
                    txtBonus.setText(model.getValueAt(selectedRow, 6) == null ? "" : model.getValueAt(selectedRow, 6).toString());
                }
            }
        });

        loadEmployees();
        setVisible(true);
    }

    private void addEmployee() {
        try {
            String sql = "INSERT INTO employees (name, age, salary, designation, overtime_rate, bonus, tax_amount, net_salary) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);

            String name = txtName.getText();
            int age = Integer.parseInt(txtAge.getText());
            double salary = Double.parseDouble(txtSalary.getText());
            String designation = txtDesignation.getText();

            double overtimeRate = 0.0;
            double bonus = 0.0;

            if (designation.equalsIgnoreCase("Manager")) {
                overtimeRate = txtOvertime.getText().isEmpty() ? 0.0 : Double.parseDouble(txtOvertime.getText());
            } else if (designation.equalsIgnoreCase("Executive")) {
                bonus = txtBonus.getText().isEmpty() ? 0.0 : Double.parseDouble(txtBonus.getText());
            }

            double tax = salary * 0.125;
            double netSalary = salary - tax + bonus + overtimeRate;

            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setDouble(3, salary);
            pstmt.setString(4, designation);
            pstmt.setDouble(5, overtimeRate);
            pstmt.setDouble(6, bonus);
            pstmt.setDouble(7, tax);
            pstmt.setDouble(8, netSalary);

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, " Employee Added Successfully!");
            loadEmployees();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void updateEmployee() {
        try {
            int selectedRow = table.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this, "Select an employee to update");
                return;
            }

            int id = (int) model.getValueAt(selectedRow, 0);

            String sql = "UPDATE employees SET name=?, age=?, salary=?, designation=?, overtime_rate=?, bonus=?, tax_amount=?, net_salary=? WHERE id=?";
            pstmt = conn.prepareStatement(sql);

            String name = txtName.getText();
            int age = Integer.parseInt(txtAge.getText());
            double salary = Double.parseDouble(txtSalary.getText());
            String designation = txtDesignation.getText();

            double overtimeRate = 0.0;
            double bonus = 0.0;

            if (designation.equalsIgnoreCase("Manager")) {
                overtimeRate = txtOvertime.getText().isEmpty() ? 0.0 : Double.parseDouble(txtOvertime.getText());
            } else if (designation.equalsIgnoreCase("Executive")) {
                bonus = txtBonus.getText().isEmpty() ? 0.0 : Double.parseDouble(txtBonus.getText());
            }

            double tax = salary * 0.125;
            double netSalary = salary - tax + bonus + overtimeRate;

            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setDouble(3, salary);
            pstmt.setString(4, designation);
            pstmt.setDouble(5, overtimeRate);
            pstmt.setDouble(6, bonus);
            pstmt.setDouble(7, tax);
            pstmt.setDouble(8, netSalary);
            pstmt.setInt(9, id);

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Employee Updated Successfully!");
            loadEmployees();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void deleteEmployee() {
        try {
            int selectedRow = table.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this, "Select an employee to delete");
                return;
            }
            int id = (int) model.getValueAt(selectedRow, 0);

            String sql = "DELETE FROM employees WHERE id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();

            JOptionPane.showMessageDialog(this, " Employee Deleted Successfully!");
            loadEmployees();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void loadEmployees() {
        try {
            model.setRowCount(0);
            rs = stmt.executeQuery("SELECT * FROM employees");
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getDouble("salary"),
                        rs.getString("designation"),
                        rs.getObject("overtime_rate"),
                        rs.getObject("bonus"),
                        rs.getDouble("tax_amount"),
                        rs.getDouble("net_salary")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new EmployeeManagementDB();
    }
}
