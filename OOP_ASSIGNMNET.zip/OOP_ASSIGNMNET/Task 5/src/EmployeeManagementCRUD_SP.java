import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EmployeeManagementCRUD_SP extends JFrame {

    Connection conn;
    CallableStatement cstmt;
    Statement stmt;
    ResultSet rs;

    JTable table;
    DefaultTableModel model;
    JTextField txtName, txtAge, txtSalary, txtDesignation, txtOvertime, txtBonus;
    JButton btnAdd, btnUpdate, btnDelete, btnRefresh, btnShowManagers, btnShowExecutives;

    public EmployeeManagementCRUD_SP() {
        setTitle("Employee Management System - Task 5 (Stored Procedures)");
        setSize(1000, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Table model
        model = new DefaultTableModel(new String[]{
                "ID", "Name", "Age", "Salary", "Designation", "Overtime Rate", "Bonus", "Tax", "Net Salary"
        }, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // Input panel
        JPanel inputPanel = new JPanel(new GridLayout(3, 6, 10, 10));

        txtName = new JTextField();
        txtAge = new JTextField();
        txtSalary = new JTextField();
        txtDesignation = new JTextField();
        txtOvertime = new JTextField();
        txtBonus = new JTextField();

        inputPanel.add(new JLabel("Name"));
        inputPanel.add(txtName);
        inputPanel.add(new JLabel("Age"));
        inputPanel.add(txtAge);
        inputPanel.add(new JLabel("Salary"));
        inputPanel.add(txtSalary);

        inputPanel.add(new JLabel("Designation"));
        inputPanel.add(txtDesignation);
        inputPanel.add(new JLabel("Overtime Rate"));
        inputPanel.add(txtOvertime);
        inputPanel.add(new JLabel("Bonus"));
        inputPanel.add(txtBonus);

        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");
        btnShowManagers = new JButton("Show Managers");
        btnShowExecutives = new JButton("Show Executives");

        inputPanel.add(btnAdd);
        inputPanel.add(btnUpdate);
        inputPanel.add(btnDelete);
        inputPanel.add(btnRefresh);
        inputPanel.add(btnShowManagers);
        inputPanel.add(btnShowExecutives);

        add(inputPanel, BorderLayout.SOUTH);

        // Database connection
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/employee_db", "root", ""
            );
            stmt = conn.createStatement();
            JOptionPane.showMessageDialog(this, "✅ Connected to Database");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database Connection Error: " + e.getMessage());
        }

        // Button actions
        btnAdd.addActionListener(e -> addEmployee());
        btnUpdate.addActionListener(e -> updateEmployee());
        btnDelete.addActionListener(e -> deleteEmployee());
        btnRefresh.addActionListener(e -> loadEmployees());
        btnShowManagers.addActionListener(e -> loadEmployeesByDesignation("Manager"));
        btnShowExecutives.addActionListener(e -> loadEmployeesByDesignation("Executive"));

        // Table click event
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    txtName.setText(model.getValueAt(selectedRow, 1).toString());
                    txtAge.setText(model.getValueAt(selectedRow, 2).toString());
                    txtSalary.setText(model.getValueAt(selectedRow, 3).toString());
                    txtDesignation.setText(model.getValueAt(selectedRow, 4).toString());
                    txtOvertime.setText(model.getValueAt(selectedRow, 5) == null ? "" : model.getValueAt(selectedRow, 5).toString());
                    txtBonus.setText(model.getValueAt(selectedRow, 6) == null ? "" : model.getValueAt(selectedRow, 6).toString());
                }
            }
        });

        // Load initial data
        loadEmployees();
        setVisible(true);
    }

    // ---------- CALL STORED PROCEDURES ----------

    private void addEmployee() {
        try {
            if (txtName.getText().isEmpty() || txtAge.getText().isEmpty() ||
                    txtSalary.getText().isEmpty() || txtDesignation.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "⚠ Please fill all required fields");
                return;
            }

            cstmt = conn.prepareCall("{CALL insert_employee(?, ?, ?, ?, ?, ?)}");

            String name = txtName.getText();
            int age = Integer.parseInt(txtAge.getText());
            double salary = Double.parseDouble(txtSalary.getText());
            String designation = txtDesignation.getText();

            double overtimeRate = 0.0;
            double bonus = 0.0;

            if (designation.equalsIgnoreCase("Manager")) {
                overtimeRate = txtOvertime.getText().isEmpty() ? 0.0 : Double.parseDouble(txtOvertime.getText());
            } else if (designation.equalsIgnoreCase("Executive")) {
                bonus = txtBonus.getText().isEmpty() ? 0.0 : Double.parseDouble(txtBonus.getText());
            }

            cstmt.setString(1, name);
            cstmt.setInt(2, age);
            cstmt.setDouble(3, salary);
            cstmt.setString(4, designation);
            cstmt.setDouble(5, overtimeRate);
            cstmt.setDouble(6, bonus);

            cstmt.execute();
            JOptionPane.showMessageDialog(this, "✅ Employee added (Stored Procedure)!");
            loadEmployees();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error adding: " + ex.getMessage());
        }
    }

    private void updateEmployee() {
        try {
            int selectedRow = table.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this, "⚠ Select an employee to update");
                return;
            }

            int id = (int) model.getValueAt(selectedRow, 0);
            cstmt = conn.prepareCall("{CALL update_employee(?, ?, ?, ?, ?, ?, ?)}");

            String name = txtName.getText();
            int age = Integer.parseInt(txtAge.getText());
            double salary = Double.parseDouble(txtSalary.getText());
            String designation = txtDesignation.getText();

            double overtimeRate = 0.0;
            double bonus = 0.0;

            if (designation.equalsIgnoreCase("Manager")) {
                overtimeRate = txtOvertime.getText().isEmpty() ? 0.0 : Double.parseDouble(txtOvertime.getText());
            } else if (designation.equalsIgnoreCase("Executive")) {
                bonus = txtBonus.getText().isEmpty() ? 0.0 : Double.parseDouble(txtBonus.getText());
            }

            cstmt.setInt(1, id);
            cstmt.setString(2, name);
            cstmt.setInt(3, age);
            cstmt.setDouble(4, salary);
            cstmt.setString(5, designation);
            cstmt.setDouble(6, overtimeRate);
            cstmt.setDouble(7, bonus);

            cstmt.execute();
            JOptionPane.showMessageDialog(this, "✅ Employee updated (Stored Procedure)!");
            loadEmployees();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error updating: " + ex.getMessage());
        }
    }

    private void deleteEmployee() {
        try {
            int selectedRow = table.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this, "⚠ Select an employee to delete");
                return;
            }

            int id = (int) model.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            cstmt = conn.prepareCall("{CALL delete_employee(?)}");
            cstmt.setInt(1, id);
            cstmt.execute();

            JOptionPane.showMessageDialog(this, "✅ Employee deleted (Stored Procedure)!");
            loadEmployees();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error deleting: " + ex.getMessage());
        }
    }

    private void loadEmployees() {
        try {
            model.setRowCount(0);
            rs = stmt.executeQuery("SELECT * FROM employees");
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getDouble("salary"),
                        rs.getString("designation"),
                        rs.getObject("overtime_rate"),
                        rs.getObject("bonus"),
                        rs.getDouble("tax_amount"),
                        rs.getDouble("net_salary")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading: " + e.getMessage());
        }
    }

    private void loadEmployeesByDesignation(String designation) {
        try {
            model.setRowCount(0);
            cstmt = conn.prepareCall("{CALL get_employees_by_designation(?)}");
            cstmt.setString(1, designation);
            rs = cstmt.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getDouble("salary"),
                        rs.getString("designation"),
                        rs.getObject("overtime_rate"),
                        rs.getObject("bonus"),
                        rs.getDouble("tax_amount"),
                        rs.getDouble("net_salary")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error filtering: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new EmployeeManagementCRUD_SP();
    }
}
