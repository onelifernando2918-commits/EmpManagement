public class EmployeeManagement {
    public static void main(String[] args) {
        Manager m1 = new Manager("Oneli", 21, 80000, 5000);
        Executive e1 = new Executive("Sadithma", 20, 50000, 10, 200);

        m1.displayDetails();
        e1.displayDetails();
    }
}
