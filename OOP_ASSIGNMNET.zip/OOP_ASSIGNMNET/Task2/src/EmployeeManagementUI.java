import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class EmployeeManagementUI extends JFrame {
    JTextField nameField, ageField, salaryField, designationField, overtimeField;
    JButton calcBtn, saveBtn, displayBtn;
    JTable table;
    DefaultTableModel model;
    ArrayList<Employee> employees = new ArrayList<>();

    public EmployeeManagementUI() {
        setTitle("Employee Management System");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        inputPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("Age:"));
        ageField = new JTextField();
        inputPanel.add(ageField);

        inputPanel.add(new JLabel("Salary:"));
        salaryField = new JTextField();
        inputPanel.add(salaryField);

        inputPanel.add(new JLabel("Designation:"));
        designationField = new JTextField();
        inputPanel.add(designationField);

        inputPanel.add(new JLabel("Overtime Hours:"));
        overtimeField = new JTextField();
        inputPanel.add(overtimeField);

        // Buttons Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        calcBtn = new JButton("Calculate");
        saveBtn = new JButton("Save Employee");
        displayBtn = new JButton("Display Employees");

        buttonPanel.add(calcBtn);
        buttonPanel.add(saveBtn);
        buttonPanel.add(displayBtn);

        // Top panel (inputs + buttons stacked vertically)
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.add(inputPanel);
        topPanel.add(buttonPanel);

        add(topPanel, BorderLayout.NORTH);

        // Table
        String[] columnNames = {"Name", "Age", "Salary", "Designation", "Overtime", "Tax", "Overtime Pay", "Net Salary"};
        model = new DefaultTableModel(columnNames, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        add(scrollPane, BorderLayout.CENTER);

        // Event Handling
        calcBtn.addActionListener(e -> calculateSalary());
        saveBtn.addActionListener(e -> saveEmployee());
        displayBtn.addActionListener(e -> displayEmployees());
    }

    private void calculateSalary() {
        try {
            String name = nameField.getText();
            int age = Integer.parseInt(ageField.getText());
            double salary = Double.parseDouble(salaryField.getText());
            String designation = designationField.getText();
            int overtime = Integer.parseInt(overtimeField.getText());

            Employee emp = new Employee(name, age, salary, designation, overtime);
            JOptionPane.showMessageDialog(this,
                    "Tax: " + emp.calculateTax() +
                            "\nOvertime Pay: " + emp.calculateOvertime() +
                            "\nNet Salary: " + emp.calculateNetSalary(),
                    "Salary Calculation",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter correct values.");
        }
    }

    private void saveEmployee() {
        try {
            String name = nameField.getText();
            int age = Integer.parseInt(ageField.getText());
            double salary = Double.parseDouble(salaryField.getText());
            String designation = designationField.getText();
            int overtime = Integer.parseInt(overtimeField.getText());

            Employee emp = new Employee(name, age, salary, designation, overtime);
            employees.add(emp);
            JOptionPane.showMessageDialog(this, "Employee Saved!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Cannot save employee.");
        }
    }

    private void displayEmployees() {
        model.setRowCount(0); // Clear table
        for (Employee emp : employees) {
            model.addRow(new Object[]{
                    emp.name,
                    emp.age,
                    emp.salary,
                    emp.designation,
                    emp.overtimeHours,
                    emp.calculateTax(),
                    emp.calculateOvertime(),
                    emp.calculateNetSalary()
            });
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new EmployeeManagementUI().setVisible(true);
        });
    }
}