import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

class Employee {
    String name;
    int age;
    double salary;
    String designation;
    int overtimeHours;

    public Employee(String name, int age, double salary, String designation, int overtimeHours) {
        this.name = name;
        this.age = age;
        this.salary = salary;
        this.designation = designation;
        this.overtimeHours = overtimeHours;
    }

    public double calculateTax() {
        return salary * 0.125; // fixed 12.5%
    }

    public double calculateOvertime() {
        return overtimeHours * 500; // Rs.500 per hour
    }

    public double calculateNetSalary() {
        return salary + calculateOvertime() - calculateTax();
    }
}

